package com.curso_simulaciones.mivigesimaquintaapp.datos;

public class AlmacenDatosRAM {
    // Pantalla
    public static float ancho_pantalla, alto_pantalla;
    public static int tamanoLetraResolucionIncluida;

    // Masas (5-25 kg)
    public static float m1 = 15f, m2 = 10f, m3 = 12f;

    // Física
    public static float a1, a2, a3;           // Aceleraciones
    public static float T1, T2, T3;           // Tensiones
    public static float tiempo;               // Tiempo simulación

    // Radio poleas
    public static float radio;

    // Posiciones (píxeles)
    public static float x1_pixeles, y1_pixeles;
    public static float x2_pixeles, y2_pixeles;
    public static float x3_pixeles, y3_pixeles;

    // Posiciones iniciales
    public static float xi1_pixeles, yi1_pixeles;
    public static float xi2_pixeles, yi2_pixeles;
    public static float xi3_pixeles, yi3_pixeles;

    // Posiciones (metros)
    public static float x1_metros, y1_metros;
    public static float x2_metros, y2_metros;
    public static float x3_metros, y3_metros;

    // Desplazamientos
    public static float desplazamiento1_metros, desplazamiento2_metros, desplazamiento3_metros;
    public static float desplazamiento1_pixeles, desplazamiento2_pixeles, desplazamiento3_pixeles;

    // Sistema coordenadas
    public static float origenX_pixeles, origenY_pixeles;

    // Rotación poleas
    public static float theta_polea1, theta_polea2, theta_polea3;

    // Conversión
    public static float factorConversion_metroApixel, factorConversion_pixelAmetro;

    // Puntos de conexión de cuerdas en poleas
    public static float conexionIzqX_pixeles, conexionIzqY_pixeles;
    public static float conexionDerX_pixeles, conexionDerY_pixeles;

    // Control
    public static boolean reiniciar = false;
}