package com.curso_simulaciones.mivigesimaquintaapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.curso_simulaciones.mivigesimaquintaapp.controlador.ActividadControladora;
import com.curso_simulaciones.mivigesimaquintaapp.datos.AlmacenDatosRAM;
import com.curso_simulaciones.mivigesimaquintaapp.utilidades.Boton;

public class ActividadPrincipalMiVigesimaQuintaApp extends Activity {

    private Boton entrar, salir;
    private ImageView imagen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gestionarResolucion();
        creacionElementosGui();

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        this.setContentView(crearGUI(), layoutParams);

        eventos();
    }

    private void gestionarResolucion() {
        DisplayMetrics metrics = getApplicationContext().getResources().getDisplayMetrics();
        int alto = metrics.heightPixels;
        int ancho = metrics.widthPixels;

        AlmacenDatosRAM.ancho_pantalla = ancho;
        AlmacenDatosRAM.alto_pantalla = alto;

        int dimensionReferencia = Math.min(alto, ancho);
        int tamanoLetra = dimensionReferencia / 20;
        AlmacenDatosRAM.tamanoLetraResolucionIncluida =
                (int) (tamanoLetra / metrics.scaledDensity);
    }

    private void creacionElementosGui() {
        entrar = new Boton(this);
        entrar.setImagen(R.drawable.entrar);
        entrar.setScaleType(ImageView.ScaleType.CENTER_CROP);

        salir = new Boton(this);
        salir.setImagen(R.drawable.salir);
        salir.setScaleType(ImageView.ScaleType.CENTER_CROP);


        imagen = new ImageView(this);
        imagen.setImageResource(R.drawable.poleas);
        imagen.setScaleType(ImageView.ScaleType.CENTER_CROP);
    }

    private LinearLayout crearGUI() {
        LinearLayout principal = new LinearLayout(this);
        principal.setOrientation(LinearLayout.VERTICAL);
        principal.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.FILL);
        principal.setBackgroundColor(Color.WHITE);
        principal.setWeightSum(10);

        // Fila 1: Imagen
        LinearLayout fila1 = new LinearLayout(this);
        fila1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0);
        params1.weight = 8.0f;
        fila1.setLayoutParams(params1);
        fila1.setGravity(Gravity.CENTER);

        imagen.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        fila1.addView(imagen);

        // Fila 2: Botones
        LinearLayout fila2 = new LinearLayout(this);
        fila2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0);
        params2.weight = 2.0f;
        fila2.setWeightSum(2);
        fila2.setLayoutParams(params2);

        LinearLayout.LayoutParams paramsBoton = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT);
        paramsBoton.weight = 1.0f;
        paramsBoton.setMargins(10, 10, 10, 10);

        entrar.setLayoutParams(paramsBoton);
        salir.setLayoutParams(paramsBoton);

        fila2.addView(entrar);
        fila2.addView(salir);

        principal.addView(fila1);
        principal.addView(fila2);

        return principal;
    }

    private void eventos() {
        entrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ActividadPrincipalMiVigesimaQuintaApp.this,
                        ActividadControladora.class);
                startActivity(intent);
            }
        });

        salir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
}