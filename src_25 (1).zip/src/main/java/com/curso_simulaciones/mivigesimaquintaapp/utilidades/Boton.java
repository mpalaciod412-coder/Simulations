package com.curso_simulaciones.mivigesimaquintaapp.utilidades;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.ImageView;

public class Boton extends ImageView {

    private Bitmap imagen;
    private String texto = "";
    private Paint pincelTexto;

    public Boton(Context context) {
        super(context);
        init();
    }

    public Boton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        pincelTexto = new Paint();
        pincelTexto.setAntiAlias(true);
        pincelTexto.setColor(Color.BLACK);
        pincelTexto.setTextAlign(Paint.Align.CENTER);
    }

    public void setText(String texto) {
        this.texto = texto;
        invalidate();
    }

    public void setImagen(int idRecurso) {
        imagen = BitmapFactory.decodeResource(getResources(), idRecurso);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (imagen != null) {
            // Escalar imagen al 80% del botón
            int nuevoAncho = (int)(getWidth() * 0.8f);
            int nuevoAlto = (int)(getHeight() * 0.6f);

            Bitmap escalada = Bitmap.createScaledBitmap(imagen, nuevoAncho, nuevoAlto, true);

            // Dibujar imagen centrada
            int x = (getWidth() - escalada.getWidth()) / 2;
            int y = (int)(getHeight() * 0.1f);
            canvas.drawBitmap(escalada, x, y, null);

            // Dibujar texto
            pincelTexto.setTextSize(getHeight() * 0.15f);
            float yTexto = y + escalada.getHeight() + getHeight() * 0.2f;
            canvas.drawText(texto, getWidth() / 2f, yTexto, pincelTexto);
        }
    }
}