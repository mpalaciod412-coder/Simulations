package com.curso_simulaciones.mivigesimaquintaapp.controlador;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.curso_simulaciones.mivigesimaquintaapp.R;
import com.curso_simulaciones.mivigesimaquintaapp.datos.AlmacenDatosRAM;
import com.curso_simulaciones.mivigesimaquintaapp.vista.CR;
import com.curso_simulaciones.mivigesimaquintaapp.vista.Pizarra;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Cuerda;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.CuerpoRectangular;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Flecha;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Marca;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Masa;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.ObjetoLaboratorio;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Polea;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.Regla;

public class ActividadControladora extends Activity {

    // ATRIBUTOS

    private int tamanoLetraResolucionIncluida;
    private Pizarra pizarra;
    private TextView text_m1, text_m2, text_m3;
    private SeekBar seek_bar_m1, seek_bar_m2, seek_bar_m3;
    private Button boton_empezar, boton_pausar;

    private float m1 = 15f, m2 = 10f, m3 = 12f;

    private CuerpoRectangular bloqueAmarillo, baseVerde;
    private Polea poleaAzulIzq, poleaAzulDer, poleaMovil;
    private Masa masa1, masa2, masa3;
    private Cuerda cuerdaSuperior, cuerdaM1, cuerdaDerecha, cuerdaM2, cuerdaM3;

    private ObjetoLaboratorio[] objetos = new ObjetoLaboratorio[20];
    private HiloAnimacion hilo;

    private float radio;
    private float anchoBloque, altoBloque;
    private float x1, y1, x2, y2, x3, y3;
    private float xPoleaIzq, yPoleaIzq, xPoleaDer, yPoleaDer, xPoleaMovil, yPoleaMovil;

    private float puntoConexionIzqX, puntoConexionIzqY;
    private float puntoConexionDerX, puntoConexionDerY;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gestionarResolucion();
        crearElementosGUI();
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        this.setContentView(crearGUI(), params);
        hilo = new HiloAnimacion(this);
        hilo.start();
        eventos();
    }

    private void gestionarResolucion() {
        tamanoLetraResolucionIncluida = (int)(0.8f * AlmacenDatosRAM.tamanoLetraResolucionIncluida);
        CR.anchoPizarra = 0.80f * AlmacenDatosRAM.alto_pantalla;
        CR.altoPizarra = AlmacenDatosRAM.ancho_pantalla;
    }

    private void crearElementosGUI() {

        // SEEK BARS
        text_m1 = new TextView(this);
        text_m1.setTextSize(TypedValue.COMPLEX_UNIT_SP, tamanoLetraResolucionIncluida);
        text_m1.setGravity(Gravity.CENTER);
        text_m1.setTextColor(Color.BLACK);
        text_m1.setText("MASA M1\n5 a 25 kg");

        text_m2 = new TextView(this);
        text_m2.setTextSize(TypedValue.COMPLEX_UNIT_SP, tamanoLetraResolucionIncluida);
        text_m2.setGravity(Gravity.CENTER);
        text_m2.setTextColor(Color.BLACK);
        text_m2.setText("MASA M2\n5 a 25 kg");

        text_m3 = new TextView(this);
        text_m3.setTextSize(TypedValue.COMPLEX_UNIT_SP, tamanoLetraResolucionIncluida);
        text_m3.setGravity(Gravity.CENTER);
        text_m3.setTextColor(Color.BLACK);
        text_m3.setText("MASA M3\n5 a 25 kg");

        seek_bar_m1 = new SeekBar(this);
        seek_bar_m1.setMax(20);
        seek_bar_m1.setProgress(10);
        AlmacenDatosRAM.m1 = m1;

        seek_bar_m2 = new SeekBar(this);
        seek_bar_m2.setMax(20);
        seek_bar_m2.setProgress(5);
        AlmacenDatosRAM.m2 = m2;

        seek_bar_m3 = new SeekBar(this);
        seek_bar_m3.setMax(20);
        seek_bar_m3.setProgress(7);
        AlmacenDatosRAM.m3 = m3;

        boton_empezar = new Button(this);
        boton_empezar.setTextSize(TypedValue.COMPLEX_UNIT_SP, tamanoLetraResolucionIncluida);
        boton_empezar.setText("EMPEZAR");
        boton_empezar.getBackground().setColorFilter(Color.rgb(220, 156, 80), PorterDuff.Mode.MULTIPLY);

        boton_pausar = new Button(this);
        boton_pausar.setTextSize(TypedValue.COMPLEX_UNIT_SP, tamanoLetraResolucionIncluida);
        boton_pausar.setText("PAUSAR");
        boton_pausar.getBackground().setColorFilter(Color.rgb(220, 156, 80), PorterDuff.Mode.MULTIPLY);
        boton_pausar.setEnabled(false);

        pizarra = new Pizarra(this);
        pizarra.setBackgroundColor(Color.WHITE);
        pizarra.setSistemaCoordenadas(CR.pcApxX(10), CR.pcApxY(10), 1, 1);

        crearObjetosLaboratorio();
    }

    private LinearLayout crearGUI() {
        LinearLayout linearPrincipal = new LinearLayout(this);
        linearPrincipal.setOrientation(LinearLayout.HORIZONTAL);
        linearPrincipal.setWeightSum(10.0f);

        LinearLayout linearIzquierda = new LinearLayout(this);
        linearIzquierda.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams paramsIzq = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT);
        paramsIzq.weight = 8.0f;
        linearPrincipal.addView(linearIzquierda, paramsIzq);

        LinearLayout linearDerecha = new LinearLayout(this);
        linearDerecha.setOrientation(LinearLayout.VERTICAL);
        linearDerecha.setBackgroundColor(Color.YELLOW);
        LinearLayout.LayoutParams paramsDer = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT);
        paramsDer.weight = 2.0f;
        linearPrincipal.addView(linearDerecha, paramsDer);

        linearIzquierda.addView(pizarra);

        LinearLayout.LayoutParams paramsComp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        paramsComp.weight = 1.0f;
        paramsComp.setMargins(5,5,5,5);

        linearDerecha.addView(text_m1, paramsComp);
        linearDerecha.addView(seek_bar_m1, paramsComp);
        linearDerecha.addView(text_m2, paramsComp);
        linearDerecha.addView(seek_bar_m2, paramsComp);
        linearDerecha.addView(text_m3, paramsComp);
        linearDerecha.addView(seek_bar_m3, paramsComp);
        linearDerecha.addView(boton_empezar, paramsComp);
        linearDerecha.addView(boton_pausar, paramsComp);

        return linearPrincipal;
    }

    private void eventos() {
        boton_empezar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (boton_empezar.getText().equals("EMPEZAR")) {
                    hilo.pausa = false;
                    seek_bar_m1.setEnabled(false);
                    seek_bar_m2.setEnabled(false);
                    seek_bar_m3.setEnabled(false);
                    boton_empezar.setText("NUEVO");
                    boton_pausar.setEnabled(true);
                    boton_pausar.setText("PAUSAR");
                } else {
                    hilo.pausa = true;
                    seek_bar_m1.setEnabled(true);
                    seek_bar_m2.setEnabled(true);
                    seek_bar_m3.setEnabled(true);
                    boton_empezar.setText("EMPEZAR");
                    boton_pausar.setEnabled(false);
                    AlmacenDatosRAM.reiniciar = true;
                }
            }
        });

        boton_pausar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (boton_pausar.getText().equals("PAUSAR")) {
                    boton_pausar.setText("CONTINUAR");
                    hilo.pausa = true;
                } else {
                    boton_pausar.setText("PAUSAR");
                    hilo.pausa = false;
                }
            }
        });

        seek_bar_m1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                m1 = 5 + progress;
                actualizarValoresIniciales();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        seek_bar_m2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                m2 = 5 + progress;
                actualizarValoresIniciales();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        seek_bar_m3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                m3 = 5 + progress;
                actualizarValoresIniciales();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    private void crearObjetosLaboratorio() {
        radio = CR.pcApxL(3.2f);
        AlmacenDatosRAM.radio = radio;
        float radioMovil = radio * 0.8f;

        anchoBloque = radio;
        altoBloque = 2 * radio;

        float bloqueX = 50f;
        float bloqueY = 50f;
        float bloqueAncho = 60f;
        float bloqueAlto = 74f;

        // BLOQUE AMARILLO
        bloqueAmarillo = new CuerpoRectangular(
                CR.pcApxX(bloqueX), CR.pcApxY(bloqueY),
                CR.pcApxL(bloqueAncho), CR.pcApxL(bloqueAlto));
        bloqueAmarillo.setColor(Color.YELLOW);
        objetos[0] = bloqueAmarillo;

        // BASE VERDE

        baseVerde = new CuerpoRectangular(
                CR.pcApxX(50), CR.pcApxY(92),
                CR.pcApxL(70), CR.pcApxL(15));
        baseVerde.setColor(Color.rgb(0, 50, 0));
        objetos[1] = baseVerde;

        // POLEAS
        float yPoleasFijas = 12.5f;

        xPoleaIzq = bloqueX - bloqueAncho/3.1f;
        yPoleaIzq = yPoleasFijas - 2.2f;
        poleaAzulIzq = new Polea(CR.pcApxX(xPoleaIzq), CR.pcApxY(yPoleaIzq), radio);
        poleaAzulIzq.setColor(Color.BLUE);
        poleaAzulIzq.rotarEje(-45);
        objetos[2] = poleaAzulIzq;

        xPoleaDer = bloqueX + bloqueAncho/3.1f;
        yPoleaDer = yPoleasFijas - 2.2f;
        poleaAzulDer = new Polea(CR.pcApxX(xPoleaDer), CR.pcApxY(yPoleaDer), radio);
        poleaAzulDer.setColor(Color.BLUE);
        poleaAzulDer.rotarEje(45);
        objetos[3] = poleaAzulDer;

        xPoleaMovil = xPoleaDer + 1.9f;
        yPoleaMovil = 50f;
        poleaMovil = new Polea(CR.pcApxX(xPoleaMovil), CR.pcApxY(yPoleaMovil), radioMovil);
        poleaMovil.setColor(Color.GREEN);
        poleaMovil.setSoportePolea(true);
        objetos[4] = poleaMovil;

        // CUERDAS

        float grosorCuerda = CR.pcApxL(0.4f);

        puntoConexionDerX = CR.pcApxX(xPoleaDer) + radio;
        puntoConexionDerY = CR.pcApxY(yPoleaDer);

        cuerdaDerecha = new Cuerda(
                puntoConexionDerX, puntoConexionDerY,
                puntoConexionDerX, CR.pcApxY(yPoleaMovil) - radioMovil);
        cuerdaDerecha.setColor(Color.RED);
        cuerdaDerecha.setGrosorLinea(grosorCuerda);
        objetos[10] = cuerdaDerecha;

        float puntoM2X = CR.pcApxX(xPoleaMovil) - radioMovil;
        y2 = 75f;
        cuerdaM2 = new Cuerda(
                puntoM2X, CR.pcApxY(yPoleaMovil),
                puntoM2X, CR.pcApxY(y2) - altoBloque/2);
        cuerdaM2.setColor(Color.RED);
        cuerdaM2.setGrosorLinea(grosorCuerda);
        objetos[11] = cuerdaM2;

        float puntoM3X = CR.pcApxX(xPoleaMovil) + radioMovil;
        y3 = 60f;
        cuerdaM3 = new Cuerda(
                puntoM3X, CR.pcApxY(yPoleaMovil),
                puntoM3X, CR.pcApxY(y3) - altoBloque/2);
        cuerdaM3.setColor(Color.RED);
        cuerdaM3.setGrosorLinea(grosorCuerda);
        objetos[12] = cuerdaM3;

        // MASAS

        x1 = xPoleaIzq - CR.pxXApc(radio);
        y1 = 65f;
        masa1 = new Masa(CR.pcApxX(x1), CR.pcApxY(y1), anchoBloque, altoBloque);
        masa1.setColor(Color.GREEN);
        masa1.setMarca("M1");
        objetos[5] = masa1;

        puntoConexionIzqX = CR.pcApxX(xPoleaIzq) - radio;
        puntoConexionIzqY = CR.pcApxY(yPoleaIzq);
        cuerdaM1 = new Cuerda(puntoConexionIzqX, puntoConexionIzqY, puntoConexionIzqX, CR.pcApxY(y1) - altoBloque/2);
        cuerdaM1.setColor(Color.RED);
        cuerdaM1.setGrosorLinea(grosorCuerda);
        objetos[9] = cuerdaM1;

        masa2 = new Masa(puntoM2X, CR.pcApxY(y2), anchoBloque, altoBloque);
        masa2.setColor(Color.GREEN);
        masa2.setMarca("M2");
        objetos[6] = masa2;

        masa3 = new Masa(puntoM3X, CR.pcApxY(y3), anchoBloque, altoBloque);
        masa3.setColor(Color.GREEN);
        masa3.setMarca("M3");
        objetos[7] = masa3;

        cuerdaSuperior = new Cuerda(
                CR.pcApxX(xPoleaIzq), CR.pcApxY(yPoleaIzq - CR.pxYApc(radio)),
                CR.pcApxX(xPoleaDer), CR.pcApxY(yPoleaDer - CR.pxYApc(radio)));
        cuerdaSuperior.setColor(Color.RED);
        cuerdaSuperior.setGrosorLinea(grosorCuerda);
        objetos[8] = cuerdaSuperior;

        AlmacenDatosRAM.xi1_pixeles = CR.pcApxX(x1);
        AlmacenDatosRAM.yi1_pixeles = CR.pcApxY(y1);
        AlmacenDatosRAM.xi2_pixeles = puntoM2X;
        AlmacenDatosRAM.yi2_pixeles = CR.pcApxY(y2);
        AlmacenDatosRAM.xi3_pixeles = puntoM3X;
        AlmacenDatosRAM.yi3_pixeles = CR.pcApxY(y3);

        AlmacenDatosRAM.y1_pixeles = AlmacenDatosRAM.yi1_pixeles;
        AlmacenDatosRAM.y2_pixeles = AlmacenDatosRAM.yi2_pixeles;
        AlmacenDatosRAM.y3_pixeles = AlmacenDatosRAM.yi3_pixeles;

        pizarra.setEstadoEscena(objetos);
    }

    public void cambiarEstadosEscenaPizarra() {
        masa1.mover(0, AlmacenDatosRAM.desplazamiento1_pixeles);
        masa2.mover(0, AlmacenDatosRAM.desplazamiento2_pixeles);
        masa3.mover(0, AlmacenDatosRAM.desplazamiento3_pixeles);

        poleaAzulIzq.mover(AlmacenDatosRAM.theta_polea1);
        poleaAzulDer.mover(AlmacenDatosRAM.theta_polea2);
        poleaMovil.mover(0, AlmacenDatosRAM.desplazamiento2_pixeles, AlmacenDatosRAM.theta_polea3);

        float radioMovil = radio * 0.8f;
        float yPoleaMovilActual = CR.pcApxY(yPoleaMovil) + AlmacenDatosRAM.desplazamiento2_pixeles;

        cuerdaM1.setPosicionFinal(puntoConexionIzqX, AlmacenDatosRAM.y1_pixeles - altoBloque/2);

        cuerdaDerecha.setPosicionFinal(puntoConexionDerX, yPoleaMovilActual - radioMovil);

        float puntoM2XActual = CR.pcApxX(xPoleaMovil) - radioMovil;
        cuerdaM2.setPosicionInicial(puntoM2XActual, yPoleaMovilActual);
        cuerdaM2.setPosicionFinal(puntoM2XActual, AlmacenDatosRAM.y2_pixeles - altoBloque/2);

        float puntoM3XActual = CR.pcApxX(xPoleaMovil) + radioMovil;
        cuerdaM3.setPosicionInicial(puntoM3XActual, yPoleaMovilActual);
        cuerdaM3.setPosicionFinal(puntoM3XActual, AlmacenDatosRAM.y3_pixeles - altoBloque/2);

        pizarra.invalidate();
    }

    public void reiniciarPosicionesIniciales() {
        masa1.mover(0, 0);
        masa2.mover(0, 0);
        masa3.mover(0, 0);
        poleaAzulIzq.mover(0);
        poleaAzulDer.mover(0);
        poleaMovil.mover(0, 0, 0);

        float radioMovil = radio * 0.8f;
        cuerdaM1.setPosicionFinal(puntoConexionIzqX, CR.pcApxY(y1) - altoBloque/2);
        cuerdaDerecha.setPosicionFinal(puntoConexionDerX, CR.pcApxY(yPoleaMovil) - radioMovil);

        float puntoM2X = CR.pcApxX(xPoleaMovil) - radioMovil;
        cuerdaM2.setPosicionInicial(puntoM2X, CR.pcApxY(yPoleaMovil));
        cuerdaM2.setPosicionFinal(puntoM2X, CR.pcApxY(y2) - altoBloque/2);

        float puntoM3X = CR.pcApxX(xPoleaMovil) + radioMovil;
        cuerdaM3.setPosicionInicial(puntoM3X, CR.pcApxY(yPoleaMovil));
        cuerdaM3.setPosicionFinal(puntoM3X, CR.pcApxY(y3) - altoBloque/2);

        AlmacenDatosRAM.y1_pixeles = AlmacenDatosRAM.yi1_pixeles;
        AlmacenDatosRAM.y2_pixeles = AlmacenDatosRAM.yi2_pixeles;
        AlmacenDatosRAM.y3_pixeles = AlmacenDatosRAM.yi3_pixeles;
        AlmacenDatosRAM.desplazamiento1_pixeles = 0;
        AlmacenDatosRAM.desplazamiento2_pixeles = 0;
        AlmacenDatosRAM.desplazamiento3_pixeles = 0;

        pizarra.invalidate();
    }

    private void actualizarValoresIniciales() {
        AlmacenDatosRAM.m1 = m1;
        AlmacenDatosRAM.m2 = m2;
        AlmacenDatosRAM.m3 = m3;
    }
}