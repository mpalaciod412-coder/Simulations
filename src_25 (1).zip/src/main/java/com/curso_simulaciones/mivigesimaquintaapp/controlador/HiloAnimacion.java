package com.curso_simulaciones.mivigesimaquintaapp.controlador;

import com.curso_simulaciones.mivigesimaquintaapp.datos.AlmacenDatosRAM;
import com.curso_simulaciones.mivigesimaquintaapp.modelo.ModeloFisico;

public class HiloAnimacion extends Thread {

    public boolean pausa = true;
    private boolean corriendo;
    private long periodo_muestreo = 100; // ms
    public float tiempo = 0;

    private ModeloFisico modelo = new ModeloFisico();
    private ActividadControladora actividad;

    public HiloAnimacion(ActividadControladora actividad) {
        this.actividad = actividad;
    }

    @Override
    public void run() {
        corriendo = true;
        while (corriendo) {
            try {
                Thread.sleep(periodo_muestreo);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (!pausa) {
                tiempo += 0.01f; // Incremento de tiempo
                calcularYActualizar();
            }
        }
    }

    private void calcularYActualizar() {
        modelo.calcularSistema(tiempo,
                AlmacenDatosRAM.m1,
                AlmacenDatosRAM.m2,
                AlmacenDatosRAM.m3);

        actividad.cambiarEstadosEscenaPizarra();

        if (modelo.verificarLimites() || AlmacenDatosRAM.reiniciar) {
            tiempo = 0;
            AlmacenDatosRAM.reiniciar = false;
            actividad.reiniciarPosicionesIniciales();
        }
    }

    public void detener() {
        corriendo = false;
    }
}