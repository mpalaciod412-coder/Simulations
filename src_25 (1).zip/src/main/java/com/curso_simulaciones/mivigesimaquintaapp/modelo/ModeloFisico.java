package com.curso_simulaciones.mivigesimaquintaapp.modelo;

import com.curso_simulaciones.mivigesimaquintaapp.datos.AlmacenDatosRAM;
import com.curso_simulaciones.mivigesimaquintaapp.vista.CR;

public class ModeloFisico {

    private float g = 9.8f;
    private float factorConversion_metroApixel;
    private float factorConversion_pixelAmetro;

    public ModeloFisico() {}

    public void calcularSistema(float tiempo, float m1, float m2, float m3) {
        factorConversion();

        // 1. CÁLCULO DE ACELERACIONES
        float numA1 = m1 * m3 + m1 * m2 - 4 * m2 * m3;
        float denA1 = m1 * m3 + m1 * m2 + 4 * m2 * m3;
        float a1 = g * (numA1 / denA1);

        float TA = m1 * (g - a1);
        float a2 = g - (TA / (2 * m2));
        float a3 = -2 * a1 - a2;

        // 2. CÁLCULO DE DESPLAZAMIENTOS
        float d1_m = 0.5f * a1 * tiempo * tiempo;
        float d2_m = 0.5f * a2 * tiempo * tiempo;
        float d3_m = 0.5f * a3 * tiempo * tiempo;

        // 3. ACTUALIZACIÓN DE  DATOS
        AlmacenDatosRAM.a1 = a1;
        AlmacenDatosRAM.a2 = a2;
        AlmacenDatosRAM.a3 = a3;
        AlmacenDatosRAM.T1 = TA;
        AlmacenDatosRAM.T2 = TA / 2f;

        AlmacenDatosRAM.desplazamiento1_pixeles = d1_m * factorConversion_metroApixel;
        AlmacenDatosRAM.desplazamiento2_pixeles = d2_m * factorConversion_metroApixel;
        AlmacenDatosRAM.desplazamiento3_pixeles = d3_m * factorConversion_metroApixel;

        AlmacenDatosRAM.y1_pixeles = AlmacenDatosRAM.yi1_pixeles + AlmacenDatosRAM.desplazamiento1_pixeles;
        AlmacenDatosRAM.y2_pixeles = AlmacenDatosRAM.yi2_pixeles + AlmacenDatosRAM.desplazamiento2_pixeles;
        AlmacenDatosRAM.y3_pixeles = AlmacenDatosRAM.yi3_pixeles + AlmacenDatosRAM.desplazamiento3_pixeles;

        // Convertir la posición actual de píxeles a metros
        AlmacenDatosRAM.y1_metros = AlmacenDatosRAM.y1_pixeles * factorConversion_pixelAmetro;
        AlmacenDatosRAM.y2_metros = AlmacenDatosRAM.y2_pixeles * factorConversion_pixelAmetro;
        AlmacenDatosRAM.y3_metros = AlmacenDatosRAM.y3_pixeles * factorConversion_pixelAmetro;

        // Rotación de poleas
        float radio = AlmacenDatosRAM.radio;
        AlmacenDatosRAM.theta_polea1 = (float)Math.toDegrees(AlmacenDatosRAM.desplazamiento1_pixeles / radio);
        AlmacenDatosRAM.theta_polea2 = (float)Math.toDegrees(AlmacenDatosRAM.desplazamiento1_pixeles / radio);
        AlmacenDatosRAM.theta_polea3 = (float)Math.toDegrees((AlmacenDatosRAM.desplazamiento2_pixeles - AlmacenDatosRAM.desplazamiento3_pixeles) / (2 * radio));

        AlmacenDatosRAM.tiempo = tiempo;
    }

    private void factorConversion() {
        factorConversion_metroApixel = CR.altoPizarra / 2.0f;
        factorConversion_pixelAmetro = 2.0f / CR.altoPizarra;
    }

    // Límites
    public boolean verificarLimites() {

        float limiteSuperior = CR.pcApxY(22);

        float limiteInferior = CR.pcApxY(80);

        // Si cualquiera de las 3 masas sale de este rango reinicia
        boolean fueraM1 = AlmacenDatosRAM.y1_pixeles < limiteSuperior || AlmacenDatosRAM.y1_pixeles > limiteInferior;
        boolean fueraM2 = AlmacenDatosRAM.y2_pixeles < limiteSuperior || AlmacenDatosRAM.y2_pixeles > limiteInferior;
        boolean fueraM3 = AlmacenDatosRAM.y3_pixeles < limiteSuperior || AlmacenDatosRAM.y3_pixeles > limiteInferior;


        float yPoleaMovilActual = CR.pcApxY(50) + AlmacenDatosRAM.desplazamiento2_pixeles;
        boolean fueraPoleaMovil = yPoleaMovilActual < limiteSuperior;

        return fueraM1 || fueraM2 || fueraM3 || fueraPoleaMovil;
    }
}