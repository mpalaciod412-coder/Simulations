package com.curso_simulaciones.mivigesimaquintaapp.vista;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.curso_simulaciones.mivigesimaquintaapp.datos.AlmacenDatosRAM;
import com.curso_simulaciones.simulphysics.objetos_laboratorio.ObjetoLaboratorio;

public class Pizarra extends View {

    private ObjetoLaboratorio[] objetosLab;
    private float origen_x, origen_y;
    private float m_x = 1, m_y = 1;

    public Pizarra(Context context) {
        super(context);
    }

    public void setSistemaCoordenadas(float origen_x, float origen_y, float m_x, float m_y) {
        this.origen_x = origen_x;
        this.origen_y = origen_y;
        this.m_x = m_x;
        this.m_y = m_y;
    }

    public void setEstadoEscena(ObjetoLaboratorio[] cuerpos) {
        this.objetosLab = cuerpos;
    }

    private void dibujarEscena(Canvas canvas, Paint pincel) {
        if (objetosLab != null) {
            for (int i = 0; i < objetosLab.length; i++) {
                if (objetosLab[i] != null) {
                    objetosLab[i].dibujese(canvas, pincel);
                }
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint pincel = new Paint();
        pincel.setAntiAlias(true);

        canvas.save();
        canvas.translate(origen_x, origen_y);
        canvas.scale(m_x, m_y);

        dibujarEscena(canvas, pincel);
        canvas.restore();

        dibujarLetreros(canvas, pincel);
        invalidate();
    }

    private void dibujarLetreros(Canvas canvas, Paint pincel) {
        pincel.setTextSize(CR.pcApxL(2.5f));
        pincel.setColor(Color.rgb(100, 100, 100));

        // Masas
        canvas.drawText("m1 = " + AlmacenDatosRAM.m1 + " kg",
                CR.pcApxX(2), CR.pcApxY(5), pincel);
        canvas.drawText("m2 = " + AlmacenDatosRAM.m2 + " kg",
                CR.pcApxX(2), CR.pcApxY(10), pincel);
        canvas.drawText("m3 = " + AlmacenDatosRAM.m3 + " kg",
                CR.pcApxX(2), CR.pcApxY(15), pincel);

        // Aceleraciones
        canvas.drawText("a1 = " + String.format("%.2f", AlmacenDatosRAM.a1) + " m/s²",
                CR.pcApxX(2), CR.pcApxY(20), pincel);
        canvas.drawText("a2 = " + String.format("%.2f", AlmacenDatosRAM.a2) + " m/s²",
                CR.pcApxX(2), CR.pcApxY(25), pincel);
        canvas.drawText("a3 = " + String.format("%.2f", AlmacenDatosRAM.a3) + " m/s²",
                CR.pcApxX(2), CR.pcApxY(30), pincel);

        // Tensiones
        canvas.drawText("T1 = " + String.format("%.2f", AlmacenDatosRAM.T1) + " N",
                CR.pcApxX(2), CR.pcApxY(35), pincel);
        canvas.drawText("T2 = " + String.format("%.2f", AlmacenDatosRAM.T2) + " N",
                CR.pcApxX(2), CR.pcApxY(40), pincel);
        canvas.drawText("T3 = " + String.format("%.2f", AlmacenDatosRAM.T3) + " N",
                CR.pcApxX(2), CR.pcApxY(45), pincel);

        // Posiciones
        canvas.drawText("y1 = " + String.format("%.3f", AlmacenDatosRAM.y1_metros) + " m",
                CR.pcApxX(2), CR.pcApxY(50), pincel);
        canvas.drawText("y2 = " + String.format("%.3f", AlmacenDatosRAM.y2_metros) + " m",
                CR.pcApxX(2), CR.pcApxY(55), pincel);
        canvas.drawText("y3 = " + String.format("%.3f", AlmacenDatosRAM.y3_metros) + " m",
                CR.pcApxX(2), CR.pcApxY(60), pincel);

        // Tiempo
        canvas.drawText("t = " + String.format("%.2f", AlmacenDatosRAM.tiempo) + " s",
                CR.pcApxX(2), CR.pcApxY(65), pincel);

        // Autor
        pincel.setTextSize(CR.pcApxL(2f));
        canvas.drawText("Maria Carolina Palacio Duque",
                CR.pcApxX(2), CR.pcApxY(95), pincel);
    }
}